# translator-en

My translator!

This training app allows you to learn words from other languages!

Оpen the main.py file and take a good look at the code!
